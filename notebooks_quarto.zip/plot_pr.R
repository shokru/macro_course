gen_price <- function(r_f     = 0.02,           # Risk-free rate
                      R_f     = 1+0.02,          # Gross risk-free rate
                      sigma_d = 0.005,          # Volatility of dividends
                      cor_d   = 0.1,            # Correlation between dividends
                      sigma_s = 0.1,            # Volatility of supply shocks
                      cor_s   = 0.7,            # Correlation between supply shocks
                      theta_f = 2,              # Risk aversion for fundamentalists
                      theta_m = 1,              # Risk aversion for momentum traders
                      delta   = 0.8,            # Exp-weighted moving average param for means
                      lambda  = 0.9,            # Momentum trader covariance shrinkage
                      n_f     = 0.5,            # Proportion of fundamentalists on the market
                      n_m     = 1-0.5,          # Proportion of momentum traders
                      d_0     = c(0.02, 0.03),  # Starting point for dividends
                      s_0     = c(1,1),         # Starting point for supply  
                      p_0     = c(1,1),         # Starting point for prices
                      E_0     = c(1,1),         # Starting point for expectations
                      Omega_0 = matrix(c(0.01, 0.005, 0.005, 0.01), nrow = 2),
                      Tt, n_sim){
  prices <- c()  
  for(j in 1:n_sim){  
    set.seed(j)                          # Random seed
    
    p <- matrix(1, ncol = 2, nrow = Tt)   # Prices
    E <- matrix(0, ncol = 2, nrow = Tt)   # Expectations
    u <- matrix(0, ncol = 2, nrow = Tt)   # Sample averages (weighted)
    Omega <- array(0, dim = c(Tt, 2, 2))  # Estimated covariances 
    V <- array(0, dim = c(Tt, 2, 2))      # Historical covariances 
    
    d   <- d_0 + rmvnorm(Tt, mean = c(0,0), sigma = Sigma_d) # Dividends
    sup <- s_0 + rmvnorm(Tt, mean = c(0,0), sigma = Sigma_s) # Supply
    
    Sigma_d <- matrix(c(sigma_d^2, sigma_d^2*cor_d, sigma_d^2*cor_d, sigma_d^2), nrow = 2)
    Sigma_s <- matrix(c(sigma_s^2, sigma_s^2*cor_s, sigma_s^2*cor_s, sigma_s^2), nrow = 2)
    alpha   <- 0.5 * diag(2)
    gamma   <- 0.5 * diag(2) 
    
    for(t in 2:Tt){
      u[t,] <- u_mean(u[t-1,], p[t-1,], delta)
      V[t,,] <- V_cov(u[t-1,], V[t-1,,], p[t-1,], delta)
      Omega[t,,] <- Omega_c(n_f, n_m, theta_f, theta_m, Omega_0, lambda, V[t-1,,])
      p[t,] <- price(R_f, n_f, n_m, theta_f, theta_m, p[t-1,], u[t-1,],
                     Omega_0, lambda, V[t-1,,], alpha, gamma, s_0, sup[t,], d[t,])
    }
    p <- p[-1,]
    prices <- bind_rows(
      prices,
      tibble(time = 2:Tt, A1 = p[,1], A2 = p[,2], simulation = j) 
    )
  }
  prices
}